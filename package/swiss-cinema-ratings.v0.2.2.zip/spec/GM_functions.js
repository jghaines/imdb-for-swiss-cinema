
// function GM_xmlhttpRequest(url, callback) {}

function GM_log(message){
	//alert(message);
}

