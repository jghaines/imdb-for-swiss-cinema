#!/bin/bash

cd extensions
zip -r ../package/swiss-cinema-ratings.zip *
cd ..
